<?php include 'header.php'; ?>
<div class="container-fluid" style="background-color: #FFF8DC; padding-left:0px; padding-right: 0px; padding-bottom: 20px;">
    <div class="container-fluid"style="background-color:#000080;color:white;">
        <h2>PRODUCTS</h2>
    </div><br>
    <div class="container-fluid">
        <div class="col-sm-4" style="background-color:#000080;color:white; font-family: 'Offside', cursive; border-radius: 5px 5px 5px 5px;">
            <h2>ELEVATORS TYPE</h2>
            <div class="list-group">
                <a href="products.php" class="list-group-item"><i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;Passenger Elevators</a>
                <a href="home-banglow-elevator.php" class="list-group-item"><i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;Home/Banglow Elevators</a>
                <a href="goods-elevators.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>&nbsp;&nbsp;Goods Elevators</a>
                <a href="hospital.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>  Hospital Elevators</a>
                <a href="capsule-lelvators.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>  Capsule Elevators</a>
                <a href="hydraulic-elevators.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>  Hydraulic Elevators</a>
                <a href="auto-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>  MRL Elevators And All Type of Auto Door Lift</a>
            </div>
            <h2>RANGE OF DOORS</h2>
            <div class="list-group">
                <a href="manual-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>MANUAL DOORS</a>
                <a href="auto-door.php" class="list-group-item active"><i class="fa fa-arrow-right" aria-hidden="true"></i>AUTO DOORS</a>
            </div>
            <h2>CAR FINISHING/CABIN TYPE</h2>
            <div class="list-group">
                <a href="auto-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i> M.S.CAR/M.S.LAMINATED/M.S. & S.S.MIX CAR</a>
                <a href="auto-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i> S.S.HAIRLINE,MIRROR FINISH & DESIGNER SHEETCAR</a>
                <a href="auto-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i> CONTROLLER & ACCESSORIES</a>
                <a href="auto-door.php" class="list-group-item "><i class="fa fa-arrow-right" aria-hidden="true"></i>PUSH BUTTON AND DISPLAY</a>
            </div>

        </div>
        <div class=""></div>
        <div class="col-sm-7 col-sm-offset-1 about" >
            <h2>S.S.CENTER OPENING AUTO DOOR</h2> 
            <hr style="width: 100%;">
            <img src="image/New Project.jpg" class="img-responsive"><br>
            <p style="text-align:justify;letter-spacing:2px;line-height: 1.5;font-size:18px;">
                Eastern canter opening door consist of two power operated panels that part simultaneously with a brisk, noiseless motion. This particular type of door is stylish in look and is ideal for spacious elevators. The door is highly secured for passengers being installed with an automatic suspension system. While in service the very door doesn't make any unwanted sound.

 We provide them at very nominal rates. Backed by our rich industrial experience in this domain we are devotedly engaged in offering premium quality Elevator Door.

The size shapes, S.S. sheet Designe, texture and itching of the door panel can be changed, as per customer choice.
            </p>
            <h2>Telescopic Auto Door</h2> 
            <hr style="width: 100%;">
            <img src="image/man.jpg" class="img-responsive"><br>
            <p style="text-align:justify;letter-spacing:2px;line-height: 1.5;font-size:18px;">
                Eastern Elevators Telescopic doors are aesthetically designed and precision-engineered for their higher performance and durable work life. Moreover, all these telescopic Doors are rigidly tested on various quality parameters to deliver a flawless range at the client's end.

The size shapes, S.S. sheet Designe, texture and itching of the door panel can be changed, as per customer choice. 
            </p>
            <h2>Glass Panel Center Auto Opening Door</h2> 
            <hr style="width: 100%;">
            <img src="image/g.jpg" class="img-responsive"><br>
            <p style="text-align:justify;letter-spacing:2px;line-height: 1.5;font-size:18px;">
                For the diverse requirements of our clients,  Eastern Elevators  engaged in supplying  and Installing a wide array of Automatic Glass Door Elevator, are capable of providing the commuters an enlarged view of outside.

it has come up with Small vision Panel glass door, Medium Vision Panel glass doors, Long Vision Panel glass doors and Border less Full vision Panel Glass Door.

According to clients' requirements, The size shapes, S.S. sheet Designe, texture and itching of the door panel can be changed, obviously without compromising with the quality. 
            </p>
            <h2>Designer Auto Door with S.S.Designer sheet itching and Glass</h2> 
            <hr style="width: 100%;">
            <img src="image/a.jpg" class="img-responsive"><br>
            <p style="text-align:justify;letter-spacing:2px;line-height: 1.5;font-size:18px;">
                Eastern Elevator bring forth a wide gamut of S.S. Designed Finished Automatic Doors for our clients. These doors are manufactured using high grade raw material which is sourced from the most reliable vendors of the market. The doors offered by us are made keeping in mind the needs and requirements of our clients. Offered doors are quality tested on various parameters by our professionals who ensure that all the products are defect-free.
            </p>
            
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
