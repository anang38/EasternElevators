<?php
$con = mysqli_connect("localhost","root","","eastern");
if(!$con)
{
    die("connection failed".mysqli_connect_error());  
}
//echo 'connect succesfully';
?>