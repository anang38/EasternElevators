<div class="container-fluid footer"><!--class="container-fluid"style="background-color:#F56B12;"-->
    <div class="col-sm-4">
         <h2 style="font-family: Dosis,arial;">QUICK LINK</h2>
         <ul>
             <li><a href="index.php">HOME</a></li>
             <li><a href="contacts.php">CONTACT</a></li>
             <li><a href="aboutus.php">ABOUT</a></li>
             <li><a href="products.php">PRODUCT</a></li>
             
        
         </ul>
    </div>
         <div class="col-sm-4">
         <h2 style="font-family:Dosis,arial;">CONTACT INFORMATION</h2>  
         <p style="line-height: 31px;"><i class="fas fa-home fa-2x" style="background:black; padding: 3px;"></i>&nbsp;&nbsp;&nbsp;11, M.N. Industrial Estate, Opp. Prasad International Hotel, Near Dahisar Check Nake, Mira Road, Mumbai-401104.</p>
         <p><i class="fas fa-globe fa-2x" style="background:black; padding: 3px;"></i>&nbsp;&nbsp;&nbsp;<a href="http://easternelevators.in">EASTERNELEVATORS</a></p>
         <p><i class="fas fa-envelope-square fa-2x"style="background:black; padding: 3px;"></i>&nbsp;&nbsp;&nbsp;easternelevators07@gmail.com</p>
         <p><i class="fas fa-phone fa-2x" style="background:black; padding: 3px;"></i>&nbsp;Phone : +91-9708114431</p>
         </div>
         <div class="col-sm-4">
         <h2 style="font-family:Dosis,arial;">FOLLOW US</h2>  
         <P style="line-height: 31px;">
             Follow us on social networks, contact us via email, you can be informed every time when we do something.
         </P>
         <a href="https://facebook.com" target="_blank"><img class="zoom" src="image/fb.png"/></a>
         &nbsp;<a href="https://twitter.com" target="_blank"><img class="zoom" src="image/t.jpg"/></a>
         &nbsp;<a href="https://whatsapp.com" target="_blank"><img class="zoom"src="image/w.png"/></a>
    </div>
    
    
</div>
<div class="container-fluid" style="background-color:black;color:wheat;">
    <div class="col-sm-4">
    <h3 style="text-align: left;">Copyright&nbsp;2018,&nbsp;EasternElevators</h3>
    </div>
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <h3 style="text-align: right;">Design And Developed by Anang.</h3>
    </div>
    
        
        
    </div>
</body>
</html>
