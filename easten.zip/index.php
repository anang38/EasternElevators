<?php include 'header.php'; ?>
<?php include 'slider.php'; ?>
<div class="container shift">
    <h2>EASTERN ELEVATORS INSTALLATION MODERNIZATION MAINTINACE AND SERVICEING COMPANY</h2>
</div>
<div class="container shift1">
    <p> We are an ISO 9001:2008 certified company with customer satisfaction and best quality as our main aim. At Eastern Elevators we possess that rare combination of professional expertise in all phases. We have undertaken various types of elevator installations.</p>
    <p>Established in 2009 essentially in the business of Elevator installation & maintenance of elevators in  Ranchi, Mumbai and Delhi   We are a full fledged elevator company having our own set up for designing creating and maintaining all types of Traction, Hydraulic, Machine room less (MRL), Manual/Automatic elevators such as passenger, bed, goods, car .We have automatic push button controls to sophisticated </p>
</div>
<div class="container-fluid shift">
    <h2 style="text-align:center;font-size: 35px;"> ​​​​​​​​​​​​​​​​​​WHY CHOOSE EASTERN ELEVATORS</h2>
    <span><p>We are one of the leading Elevator solution providers in Ranchi. We also operate </p></span>
    <span><p>in Mumbai , Delhi and other emerging areas. </p></span>
    <hr>
</div>
<div class="container-fluid" style="background-color:#FFF8DC; padding: 20px;">
    <div class="container">
        <div class="row">
        <div class="col-sm-4 ">
            <h2>SERVING CLIENTS WITH BEST PRODUCTS</h2>
            <p>We established as Eastern Elevators, with main objective of providing safe and quality product at all the time.</p>
        </div>
        <div class="col-sm-4 ">
            <h2>MORE THAN 15 YEARS OF EXPERIENCE</h2>
            <p>Our technicians possess more than 15 years of experience in installation, Commissioning and Maintenance department making us provide quality product with highest priority to safety of our clients.</p>
        </div>
        <div class="col-sm-4 ">
            <h2>CLIENT SATISFACTION MATTERS</h2>
            <p>We firmly believe that client satisfaction is very important and we try our best to provide it with our best efforts.</p>
        </div>
        </div>
    </div>
</div>
    <?php include 'footer.php'; ?>


