<?php include 'header.php'; ?>
<div class="container-fluid" style="padding-left: 0px;padding-right: 0px;">
    <div  style="background-color:#000080;color:white; font-family: 'Offside', cursive; padding: 10px;">
        <h2>OUR SERVICES</h2>
    </div>
</div>
<div class="container-fluid" style="background-color: #FFF8DC; text-align: center;padding-bottom: 20px;">
    <h2 style="color:gray;">WHY WORK WITH EASTERN ELEVATORS?</h2>
    <center><img src="image/waves.png" style="width: 20%;" class="img-responsive"></center>
    <div class="col-sm-4">
        <h1>1</h1>
        <hr>
        <h3><b>WORLD-CLASS SERVICES</b></h3>
        <p style="font-size: 17px;">Our services and solutions will support you through every step of your project.</p>
    </div>
    <div class="col-sm-4">
        <h1 >2</h1>
        <hr>
        <h3><b>A ONE-STOP SHOP</b></h3>
<p style="font-size: 17px;">We have everything you need for smooth people flow in your building.</p>
        
    </div>
    <div class="col-sm-4">
       <h1>3</h1> 
       <hr>
       <h3><b>35 YEARS OF EXPERIENCE</b></h3>
       <p style="font-size: 17px;">For more than a century we’ve been excelling at projects ranging from affordable housing to the world’s tallest buildings.</p>
    </div>
    <br>
    <h2 style="color:gray;">SOLUTIONS FOR EXISTING BUILDING</h2>
    <center><img src="image/waves.png" style="width: 20%;" class="img-responsive"></center>
    <div class="col-sm-6 div1"> 
        <img src="image/Elevator-technician-working-on-outside-of-elevator-960x588.jpg" class="img-responsive">
    </div>
    <div class="col-sm-6 div2">
        <h1>Maintenance Solutions</h1>
        <p style="text-align:justify;font-size: 18px;">

            EASTERN ELEVATORS leads the industry in advanced maintenance services for elevators, escalators, autowalks and automatic building doors. Our flexible Eastern Elevator maintenance offering is tailored to your needs and makes sure your equipment performs reliably and safely, while also extending its lifespan.</p>


<p style="text-align:justify;font-size: 18px;">Whatever brand or type of equipment you have, with EASTERN ELEVATORS you can count on maintenance expertise that will keep it running smoothly and safely for its entire lifespan – and a customer experience that is second to none.</p>
    </div>
     
     <div class="col-sm-6 div1"> 
         <img src="image/modernization-solutions-951x535_tcm17-11681 (1).jpg" class="img-responsive">
    </div>
    <div class="col-sm-6 div2">
        <h1>Modernization Solutions</h1>
        <p style="text-align:justify;font-size: 18px;">

            As populations age, ensuring smooth and convenient people flow becomes even more essential. Even well-maintained equipment can fall short of expectations as it gets older or in a changing environment. Modernizing your elevators, escalators, autowalks and automatic building doors will improve their safety, eco-efficiency, performance, and aesthetics.</p>


<p style="text-align:justify;font-size: 18px;">EASTERN ELEVATORS modernization solutions are tailored to your exact needs, ranging from component upgrades to full replacement of existing equipment, as well as retrofit installations. Their purpose is simple – to keep your equipment running safely and reliably for the lifetime of your building.</p>
    </div>
 
    <div class="col-sm-6 div1"> 
        <img src="image/464738.png" class="img-responsive">
    </div>
    <div class="col-sm-6 div2">
        <h1>Our Key Feature</h1>
        <ul style="text-align:justify;font-size: 18px;" >
            <li>Safety: Safety is top of the agenda at EASTERN ELEVATORS to full surety of all accident preventable.Our Safety Target:</li>
            <center><li>0% Accident.</li></center>
            <center><li>High Commitment</li></center>
            <li>Environment:Creating Sustainable from Small Urban to Big Smart City. Our Environmental success energy Efficiency EASTERN ELEVATORS Company to achieve Best class energy efficiency classification for an Elevator Solution.</li>
            <li>Quality:Everyone is Responsible for quality at EASTERN ELEVATORS company. In EASTERN ELEVATORS company quality is embedded in every things we do, from customer Interaction and product planning all the way to the services we offer.</li>
        </ul>
</div>
</div>
<?php include 'footer.php'; ?>
